AgriConnect-Assured Contract Farming System For Stable Market Access:
•It connects both farmers and the company directly without any mediator so that there
exists a secure and transparent agreement between a farmer and a company.
•The project aims to guaranteeing stable market access and fair pricing thereby reducing
the dependency on intermediates.
Technologies used:
React js,Express js,MongoDB,Node js (MERN Stack)
